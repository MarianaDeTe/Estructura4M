package operaciones;

import java.util.Scanner;

/**
 * Mariana Karina Vazquez Garcia
 */
public class DivisionPractica4 extends PotenciaPractica2 {

    Scanner leer = new Scanner(System.in);
    int a, b;

    /**Divisiones por resta sucesiva
     * 
     * Dentro de este método se ejecuta un "IF" que se traduce como: Si "b" es
     * mayor a "a" entonces va a regresar el valor de 0, y si no lo que regresa
     * es "división" (a – b, b) + 1, ya que no se conoce el valor de "división"
     * es aquí donde entra la recursividad pues seguirá desglosando la operación
     * hasta llegar al caso base que es igual a 0. *
     */
    public int division(int a, int b) {
        if (b > a) {//este es el caso base, aplica cuando b es mayor que a 
            return 0;
        } else {
            return division(a - b, b) + 1;//Donde 1 se utilica como un contador
        }
    }

    public void leerD() {
        System.out.println("\n\n Cuál es el dividendo?? " + " O.o??");
        a = leer.nextInt();
        System.out.println("\n\n Cuál es el divisor?? " + " O.o??");
        b = leer.nextInt();

        System.out.println("La operación queda como: " + a + " entre " + b
                + "\n\n\t\tes igual a:  " + division(a, b) + "  (°w°)");

        super.menu();//Se manda a llamar a menú(), que pertenece a la clase padre.
    }
}
