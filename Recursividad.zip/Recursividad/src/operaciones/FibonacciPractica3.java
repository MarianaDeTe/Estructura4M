package operaciones;

import java.util.Scanner;

/**Mariana Karina Vazquez Garcia
 * 
 * La serie Fibonacci es la suma entre los dos términos anteriores de la misma
 * serie, esto quiere decir que es la suma del numero anterior más el resultado.
 */

public class FibonacciPractica3 extends PotenciaPractica2 {
    Scanner leer = new Scanner(System.in);
    static int n;

    /**
     * Esta función recibe un parámetro que es "n", de tipo entero en el cual se
     * guarda el número o el índice que se quiere conocer de la serie Fibonacci.
     */
    public int fibo(int n) {
        if (n == 0 || n == 1) {//este es el caso base
            return 1;
        } else {
            return fibo(n - 1) + fibo(n - 2);
        }
    }

    public void leerF() {
        System.out.println("\n\n Con que numero vamos a empezar?? " + " O.o??");
        n = leer.nextInt();

        imprimeRes();
    }

    /**
     * Dentro del método "imprimeRes()" se guarda un while que desempeña la
     * función de imprimir todos los términos de la serie hasta un número "n".
     */
    private void imprimeRes() {
        System.out.println("\n\nTu serie de Fibonacci quedara asi: " + " (°U°)");
        System.out.println("0");

        int m = 0;

        while (m != n) { //Se activa cuando "n" es diferente de "m".
            System.out.println(fibo(m));
            /**
             * "m" se consideran las posiciones, porlo tanto lo que se imprime
             * son las posiciones.
             * “m” va aumentando de uno en uno.
             */
            m++;
        }
        super.menu();
    }
}
