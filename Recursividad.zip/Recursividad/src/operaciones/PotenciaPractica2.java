package operaciones;

import java.util.Scanner;

/**
 * Mariana Karina Vazquez Garcia
 *
 * Un método recursivo contiene dos elementos básicos que son fundamentales.
 *
 * CASO BASE: Existe al menos una solución para algún valor determinado
 * PROGRESO: Cualquier llamada a si mismo debe progresar (acercarse) a un caso
 * base
 */
public class PotenciaPractica2 {

    static int n, x;
    Scanner leer = new Scanner(System.in);

    public void menu() {
        System.out.println("\n\n (°u°)/   MENU PRINCIPAL   (°u°)/");
        System.out.println("\n\t1)Introducción");
        System.out.println("\n\t2)Suma");
        System.out.println("\n\t3)Potencia");
        System.out.println("\n\t4)Fibonacci");
        System.out.println("\n\t5)División por resta");
        System.out.println("\n\t6)Producto por suma");
        System.out.println("\n\t7)Tablas de multiplicar");
        System.out.println("\n\t8)Despedida");
        System.out.println("\n\t9)Salir");
        System.out.print("\n\nElige una opción... (°o°) \n");
        int opc = leer.nextInt();
        validaOpc(opc);
    }

    public int potencia(int x, int n) {
        if (n == 0) {//CASO BASE
            return 1;
        } else {
            /**
             * cuando el caso base es diferente de 0 entrara al "else" aqui es
             * donde empieza el PROGRESO
             */
            return x * potencia(x, n - 1);
        }
    }

    public void leerPotencia() {
        System.out.println("\n Cuál es el numero base?? " + " O.o??");
        x = leer.nextInt();
        System.out.println("\n A qué número será elevado?? " + " O.o??");
        n = leer.nextInt();

        System.out.println("\n\nLa operación queda como: " + x + " elevado a la " + n
                + "\n\n\t\t\tel resultado es:  " + potencia(x, n) + "   (°w°)");
    }

    private void validaOpc(int opc) {
        switch (opc) {
            case 1:
                introduccion();
                menu();
                break;
            case 2:
                SumaPractica1 su = new SumaPractica1();
                su.leerN();
                break;
            case 3:
                leerPotencia();
                menu();
                break;
            case 4:
                FibonacciPractica3 fi = new FibonacciPractica3();
                fi.leerF();
                break;
            case 5:
                DivisionPractica4 divi = new DivisionPractica4();
                divi.leerD();
                break;
            case 6:
                ProductoPractica5 prod = new ProductoPractica5();
                prod.leerProducto();
                break;
            case 7:
                MultiplicarPractica6 multi = new MultiplicarPractica6();
                multi.leerM();
                break;
            case 8:
                despedida();
                menu();
                break;
            case 9:
                System.exit(0);
                break;
            default:
                System.out.println("\n.....Opcion Invalida (°x°)......\n");
                menu();
                break;
        }
    }

    private void introduccion() {
        System.out.println("Hola (°u°)/");
        System.out.println("  Hola (°u°)/");
        System.out.println("    Hola (°u°)/");
        System.out.println("      Hola (°u°)/");
        System.out.println("        Hola (°u°)/");
        System.out.println("          Hola (°u°)/");
        System.out.println("            Hola (°u°)/");
        System.out.println("              Hola (°u°)/");
        System.out.println("                Hola (°u°)/");
        System.out.println("\n\t\t\t\tRECURSIVIDAD");
        System.out.println("\nUn algoritmo es recursivo cuando se define en "
                + "términos de una versión más simple de si mismo."
                + "\n\nEsto significa que es un método que simplifica ya que "
                + "solo se detendrá hasta que se acerque al caso base."
                + "\n\nEs una función que para encontrar un resultado "
                + "se manda a llamar así misma."
                + "\n\n(°U°)");
    }

    private void despedida() {
        System.out.println("Adios (°n°)/");
        System.out.println("  Adios (°n°)/");
        System.out.println("    Adios (°n°)/");
        System.out.println("      Adios (°n°)/");
        System.out.println("        Adios (°n°)/");
        System.out.println("      Adios (°n°)/");
        System.out.println("    Adios (°n°)/");
        System.out.println("  Adios (°n°)/");
        System.out.println("Adios (°n°)/");
        System.out.println("  Adios (°n°)/");
        System.out.println("    Adios (°n°)/");
        System.out.println("      Adios (°n°)/");
        System.out.println("        Adios (°n°)/");
        System.out.println("      Adios (°n°)/");
        System.out.println("    Adios (°n°)/");
        System.out.println("  Adios (°n°)/");
        System.out.println("Adios (°n°)/");
        System.out.println("  Adios (°n°)/");
        System.out.println("    Adios (°n°)/");
        System.out.println("      Adios (°n°)/");
        System.out.println("        Adios (°n°)/");
        System.out.println("      Adios (°n°)/");
        System.out.println("    Adios (°n°)/");
        System.out.println("  Adios (°n°)/");
        System.out.println("Adios (°n°)/");
        System.out.println("  Adios (°n°)/");
        System.out.println("    Adios (°n°)/");
        System.out.println("      Adios (°n°)/");
        System.out.println("        Adios (°n°)/");
        System.out.println("      Adios (°n°)/");
        System.out.println("    Adios (°n°)/");
        System.out.println("  Adios (°n°)/");
        System.out.println("Adios (°n°)/");

    }

    public static void main(String[] args) {
        PotenciaPractica2 pp = new PotenciaPractica2();
        pp.menu();
    }
}
