
package Colas;

/**
 *
 * @author Sergio
 */
public class Nodo {
    int dato;
    Nodo siguiente;
    public Nodo(int d){
    dato=d;
    siguiente=null;
    
    }
    
    public Nodo(){}
}
