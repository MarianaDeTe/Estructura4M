/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Colas;

import java.util.Scanner;


public class Principal {
    public static void main(String[] args) {
       Cola cola = new Cola();
        Scanner leer = new Scanner(System.in);
        int opcion = 0;
        do {
            
            System.out.println("Bienvenido");
            System.out.println("1.Ingresar un elemento a la cola");
            System.out.println("2.Quitar elemento de la cola");
            System.out.println("3.¿Verificar si la lista esta vacía ?");
            System.out.println("4.Elemento inicio de la cola ");
            System.out.println("5.Tamaño de la cola.");
            System.out.println("6.Mostrar cola");
            System.out.println("Escoja una opción");
            opcion = leer.nextInt();
            switch (opcion) {
                case 1:
                    System.out.println("Ingrese el dato al nodo ");
                    int dato = leer.nextInt();
                    cola.insertar(dato);
                    break;
                case 2:
                    if(!cola.estaVacia()){
                        System.out.println("El elemento atendido es "+cola.quitar());
                    }else{
                        System.out.println("La pila esta vacía");
                        
                    }
                    break;
                case 3:
                    if(cola.estaVacia()){
                        System.out.println("La cola esta vacía");
                    }else{
                        System.out.println("La cola no esta vacía ");
                    }
                    break;
                case 4:
                    if(!cola.estaVacia()){
                        System.out.println("El elemento ubicado al incio de la cola es "+cola.inicioCola());
                    }else{
                        System.out.println("La cola esta vacía");
                    }
                    break;
                case 5:
                    System.out.println("El tamaño de la cola "+cola.tamaño());
                    break;
                case 6:
                    cola.verLista();
                    
                    break;
            }
        } while (opcion != 6);        
        
    }
}
