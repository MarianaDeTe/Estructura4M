/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Colas;


public class Cola {

    Nodo inicio;
    Nodo fin;
int tamaño;
    public Cola() {
        inicio = null;
        fin = null;
tamaño=0;
    }

    public boolean estaVacia() {
        return inicio == null;

    }

    public void insertar(int ele) {//método para insertar un elemnto en la cola
//1------->2------------->3
        Nodo nuevo = new Nodo(ele);
        if (estaVacia()) {
            inicio = nuevo;
        } else {
            fin.siguiente = nuevo;
        }
        fin = nuevo;
        tamaño++;
    }

    public int quitar() {
        int auxiliar = inicio.dato;
        inicio = inicio.siguiente;
tamaño--;
        return auxiliar;
    }
    
    
    public int inicioCola(){
    return inicio.dato;
    }
    
    public int tamaño(){
    return tamaño;
    }
    
    
    public void verLista() {
        Nodo actual = new Nodo();
        actual = inicio;
        while (actual != null) {
            System.out.println(actual.dato);
            actual = actual.siguiente;//Para que se vaya actualizando la lista
        }
    }
}
