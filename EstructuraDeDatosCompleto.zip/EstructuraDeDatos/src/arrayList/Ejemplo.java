/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrayList;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *Vazquez Garcia Mariana Karina
 * 
 * add: agrega
 * remove: elimina
 * clone: copia el arrayList a otro
 */
public class Ejemplo {
    ArrayList <String> nombre = new ArrayList <String>();
    Scanner leer = new Scanner(System.in);
    
    public void inicio(){        
        nombre.add("Dulce");
        nombre.add("Arturo");
        nombre.add("Eduardo");
        nombre.add("Mariana");
        nombre.add("Karina");
        nombre.add("Vazquez");
        nombre.add("Garcia");
        nombre.add("Bryan");
        nombre.add("Hola");
        
        System.out.println(nombre);
    }
    
    public void elimina(){
        nombre.remove(2);
        System.out.println(nombre);
    }
    
    public void busca(){
        System.out.println(nombre.get(3));
        System.out.println(nombre.size());
        
        for (int i = 0; i < nombre.size(); i++) {
            System.out.println(nombre.get(i));
        }
        
        if (nombre.contains("Mariana")) {
            System.out.println("(°u°)");
        }else if(!nombre.contains("Bryan")){
            nombre.clear();
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Ejemplo ej = new Ejemplo();
        ej.inicio();
        ej.elimina();
        ej.busca();
    }
}
