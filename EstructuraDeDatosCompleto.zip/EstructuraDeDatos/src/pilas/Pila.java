/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pilas;

import java.util.Stack;
import java.util.Scanner;

/**
 * Vazquez Garcia Mariana Karina
 */
public class Pila {

    Stack<Integer> numeros = new Stack<Integer>();
    Scanner leer = new Scanner(System.in);
    int v;

    /**
     * push:  intorduce datos 
     * pop:   elimina dato 
     * peek:  muestra el ultimo dato(la sima) 
     * empty: datos vacios
     */
    public void InsertarDato() {

//        System.out.println("Introduciendo datos...");
//        System.out.println(numeros.push(1));
//        System.out.println(numeros.push(2));
//        System.out.println(numeros.push(3));
//        System.out.println(numeros.push(4));
//        System.out.println(numeros.push(5));

        System.out.println("Cuantos valores vas a ingresar O.o??? ");
        v = leer.nextInt();
        
        System.out.println("Introduciendo datos...");
        for (int i = 1; i <= v; i++) {
            
            System.out.println(numeros.push(i));
        }
    }

    public void MostrarDato() {
        while (!numeros.empty()) {
            System.out.print("\t" + numeros.peek());
            numeros.pop();
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Pila p = new Pila();
        p.InsertarDato();
        p.MostrarDato();

    }

}
