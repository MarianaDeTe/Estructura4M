/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrayvslinked;

import java.util.*;
/**
 *
 * @author Mariana
 */
public class Programa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        List<Persona>listaarray = new ArrayList<Persona>();
        List<Persona>listalinked = new ArrayList<Persona>();
        long antes;
        
        for (int i = 0; i < 10000; i++) {
            listaarray.add(new Persona(i, "Persona " + i,i));
            listalinked.add(new Persona(i, "Persona " + i,i));
        }
        System.out.println("Tiempo en insertar en listaarray (nanosegundos): ");
        antes = System.nanoTime();
        listaarray.add(0,new Persona(10001, "Prueba ",10001));
        System.out.println(System.nanoTime()-antes);
        
        System.out.println("Tiempo en insertar en listalinked (nanosegundos): ");
        antes = System.nanoTime();
        listalinked.add(0,new Persona(10001, "Prueba ",10001));
        System.out.println(System.nanoTime()-antes);
    }
    
}
