package recursividad;

import java.util.Scanner;

/**Mariana Karina Vazquez Garcia
 * 
 * Un método recursivo contiene dos elementos básicos que son fundamentales.
 * 
 * CASO BASE:       Existe al menos una solución para algún valor determinado
 * PROGRESO: 	Cualquier llamada a si mismo debe progresar (acercarse) a un caso base
 */
public class FactorialEjemplo {
    
    static int n;
    Scanner leer = new Scanner(System.in);
    
    public int fac(int n){
        if (n==1) {
            return 1;
        }else{
            return n * fac(n-1);
        }
    }
    
    public void leer(){
        System.out.println("\n\n Qué número deseas conocer??");
        n = leer.nextInt();
        System.out.println("El número calculado es: " + fac(n));
    }
    
    public static void main(String[] args) {
        FactorialEjemplo fa = new FactorialEjemplo();
        fa.leer();
    }
}
