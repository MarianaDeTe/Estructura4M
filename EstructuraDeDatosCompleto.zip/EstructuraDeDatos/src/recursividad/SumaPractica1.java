/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recursividad;

import java.util.Scanner;

/**
 * Mariana Karina Vazquez
 *
 * Un método recursivo contiene dos elementos básicos que son fundamentales.
 *
 * CASO BASE: Existe al menos una solución para algún valor determinado
 * PROGRESO: Cualquier llamada a si mismo debe progresar (acercarse) a un caso
 * base
 */
public class SumaPractica1 extends PotenciaPractica2{

    static int n;
    Scanner leer = new Scanner(System.in);

    public int suma(int n) {
        if (n == 1) {//este es el caso base
            return 1;
        } else {
            return n + suma(n - 1);
        }
    }

    /**
     * Dentro de este método se guarda en número que el usurio ingresa es a
     * partir de este número que se inicia el programa.
     */
    public void leerN() {
        System.out.println("\n\n Con que número vamos a empezar?? " + " O.o??");
        n = leer.nextInt();
        System.out.println("El número calculado es: " + suma(n));
        
        super.menu();
    }
}
