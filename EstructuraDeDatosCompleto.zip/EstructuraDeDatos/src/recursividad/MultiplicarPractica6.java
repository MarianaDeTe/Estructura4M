/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recursividad;

/**
 * Vazquez Garcia Mariana Karina
 *
 * En este método lo que se pide es calcular una tabla de multiplicar completa,
 * es decir que multiplique a partir de 1 hasta llegar al 10.
 *
 * Dentro del método "Tabla" se especifica que "e" (es la variable que va a
 * guardar el número ingresado por el usuario).
 *
 * Si "e" es mayor a 1 entrara al progreso en caso de ser menor ira al caso base
 * donde retornara 0.
 */
public class MultiplicarPractica6 extends PotenciaPractica2 {

    int num, e;

    public int Tabla(int e, int num) {
        if (e < 1) {//este es el caso base.
            return 0;
        } else {
            return Tabla(e,num - 1);
        }
    }

    public void leerM() {
        System.out.println("\n\n Qué tabla de multiplicar quieres conocer?? " + " O.o??");
        e = leer.nextInt();
        imprimeRes();
    }

    private void imprimeRes() {
        while (num != 11) {
            System.out.println("\n" + e + "*" + num + "=" + e * num);
            num++;
        }

        super.menu();
    }

}
