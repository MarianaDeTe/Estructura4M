/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recursividad;

import java.util.Scanner;

/**
 *
 * Mariana Karina Vazquez Garcia
 *
 * Obtención de un producto por suma sucesiva.
 *
 * En este caso la variable de "c" va a guardar el primer número y "d" guardara
 * el segundo valor. 
 * Para obtener el método de suma sucesiva, primero se hace
 * una igualación donde "c" y d se igualan a cero, en caso de que ambas sean cero
 * entrara al caso base donde retornara 0. 
 * Si no entrara al proceso donde guardara "c", ya que este es nuestro número
 * base y ha "d" se le quita un número, ya que la manera de trabajar de la
 * recursividad es iniciando de lo general a lo particular, es decir, comienza
 * desde el número mayor hasta el menor.  *
 */
public class ProductoPractica5 extends PotenciaPractica2 {

    static int c, d;
    Scanner leer = new Scanner(System.in);

    public int Producto(int c, int d) {
        if (c == 0 || d == 0) {//este es el caso base.
            /**
             * Aquí es donde se validan las dos variables que se ocupan
             */
            return 0;
        } else {
            return c + Producto(c, d - 1);
        }

    }

    public void leerProducto() {
        System.out.println("\n\n Cuál es el primer número?? " + " O.o??");
        c = leer.nextInt();
        System.out.println("\n\n Cuál es el segundo número?? " + " O.o??");
        d = leer.nextInt();

        System.out.println("La operación queda como: " + c + " por " + d
                + "\n\n\t\tes igual a:  " + Producto(c, d) + "  (°w°)");
        
        super.menu();
    }
}
