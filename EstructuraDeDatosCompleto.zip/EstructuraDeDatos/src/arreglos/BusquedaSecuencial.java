/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arreglos;

import java.util.Scanner;

/**
 * Vazquez Garcia Mariana Karina
 */
public class BusquedaSecuencial {

    Scanner busca = new Scanner(System.in);

    int[] A = {8, 7, 6, 5, 1};
    int num = 0;
    boolean confirma;

    public void LeerNumero() {
        System.out.println("Que numero deseas buscar: " + "O.o??");
        num = busca.nextInt();

        for (int i = 0; i < 5; i++) {
            if (num == A[i]) {
                System.out.println("\n" + num + " se encuntra en la posicion " + i);
            }else if(confirma == false){
                System.out.println("No se econtro nada en la posicion: " + i + " °n°");
            }
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        BusquedaSecuencial bs = new BusquedaSecuencial();
        bs.LeerNumero();
    }

}
