/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arreglos;

import java.util.Scanner;

/**
 * Vazquez Garcia Mariana Karina
 */
public class ArregloEjemplo {

    Scanner leer = new Scanner(System.in);
    int[] arreglo = new int[5];
    int suma = 0;
    float total = 0;

    /**
     * Dentro de este for se guardan los valores ingresados dentro de un
     * arreglo, para no tener que declarar cada variable, los valores ingresados
     * se guardaran siempre y cuando queden dentro de la declaracion(5)
     */
    public void Resuelve() {
        for (int i = 0; i < arreglo.length; i++) {
            System.out.println("Introduce un número " + " O.o??  " + i);
            arreglo[i] = leer.nextInt();
        }
    }

    public void Muestra() {
        for (int i = 0; i < arreglo.length; i++) {
            System.out.print(arreglo[i] + " ");
        }
    }

    public void Suma() {
        for (int i = 0; i < arreglo.length; i++) {
            suma += arreglo[i];
        }
        System.out.print(suma);
    }
    
    public void Promedio(){
        for (int i = 0; i < arreglo.length; i++) {
            total = suma / arreglo.length;
        }
        System.out.println(total);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArregloEjemplo arr = new ArregloEjemplo();
        arr.Resuelve();
//        arr.Muestra();
        arr.Suma();
//        arr.Promedio();
    }

}
