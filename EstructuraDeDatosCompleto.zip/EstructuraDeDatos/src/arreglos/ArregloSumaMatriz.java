/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arreglos;

import java.util.Scanner;

/**
 * Vazquez Garcia Mariana Karina
 *
 * Dentro de este método se hace un suma de matrices para eso se declaran 3
 * arreglos, en "a" estamos almacenado los primeros valores en "b" se almacenan los
 * siguientes valores, para que en "c" se guarde el resultado. Se utiliza un for
 * anidado para ingresar los números; al entrar primer for pregunta si la fila
 * es menor a la longitud inicializada entra en el segundo for donde preguntara
 * lo mismo y así asignara el primer valor en la posición 0,0
 *
 */
public class ArregloSumaMatriz {

    Scanner leer = new Scanner(System.in);
    int[][] a = new int[3][3];
    int[][] b = new int[3][3];
    int[][] c = new int[3][3];

    public void sumaMatriz() {
        for (int i = 0; i < 3; i++) {//ingresa datos en la primer matriz
            System.out.println("Fila " + i + " A");
            for (int j = 0; j < 3; j++) {
                System.out.println("ingresa número" + j);
                a[i][j] = leer.nextInt();
            }
        }

        for (int i = 0; i < 3; i++) {
            System.out.println("Fila " + i + " B");
            for (int j = 0; j < 3; j++) {
                System.out.println("ingresa número" + j);
                b[i][j] = leer.nextInt();
            }
        }

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                c[i][j] = a[i][j] + b[i][j];// suma de matrices
            }
        }

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {//muestra la matriz resultante
                System.out.print(c[i][j] + "\t");
            }
            System.out.println("\n");//separa las filas
        }
    }

    public static void main(String[] args) {
        // TODO code application logic here
        ArregloSumaMatriz suma = new ArregloSumaMatriz();
        suma.sumaMatriz();
    }

}
