/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arreglos;

import java.util.Scanner;

/**
 * Vazquez Garcia Mariana Karina
 */
public class BusquedaBinaria {

    Scanner busca = new Scanner(System.in);

    int[] A = {1, 2, 3, 4, 5, 6, 7};
    int num = 0;
    int centro = 0;
    boolean confirma;

    public void LeerNumero() {
        centro = A.length / 2;
        centro++;

        System.out.println("Que numero deseas buscar: " + "O.o??");
        num = busca.nextInt();
//        if (confirma == true) {
        if (num == centro) {
            System.out.println("\n" + num + " es el centro del arreglo");
        } /**
         * Si el número ingresado es menor al centro recorrerá el arreglo que
         * inicia en centro y termina en el final del arreglo, recorriendo de
         * uno en uno hacia la derecha. Si el número se encuentra dentro del
         * arreglo imprimirá el número y la posición en la que se encuentra.          *
         */
        else if (num > centro) {
            for (int i = centro; i < A.length; i++) {
                if (num == A[i]) {
                    System.out.println("\n" + num + " se encuntra en la posicion " + i);
                }
//                while (num > centro) {
            }
        } else if (num < centro) {
            for (int i = centro; i > -1; i--) {
                if (num == A[i]) {
                    System.out.println("\n" + num + " se encuntra en la posicion " + i);
                }
            }
        }
//        } else if (confirma == false) {
//            System.out.println("No se econtro nada " + " °n°");
//        }
    }

//        else if (num < centro) {
//            for (int j = centro; j > 0; j--) {
//                System.out.println("\n" + num + " se encuntra en la posicion " + j);
//            }
//   6     }
//        if (confirma == false) {
//            System.out.println("No se econtro nada " + " °n°");
//        }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        BusquedaBinaria bb = new BusquedaBinaria();
        bb.LeerNumero();
    }

}
