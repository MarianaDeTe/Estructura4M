/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package arreglos;

import java.util.Scanner;

/**
 *
 * @author Alumno
 */
public class ArregloMatriz {

    /**
     * @param args the command line arguments
     */
    Scanner leer = new Scanner(System.in);
    int [][] uno = new int[4][5];
    
    public void ingresa(){
        for (int i = 0; i < 4; i++) {
            System.out.println("Fila" + i);
            for (int j = 0; j < 5; j++) {
                System.out.println("ingresa número" + j);
                uno[i][j]=leer.nextInt();
            }
        }
        
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print(uno[i][j] + "\t");
            }
            System.out.println("\n");
        }
    }
    public static void main(String[] args) {
        // TODO code application logic here
        ArregloMatriz matriz = new ArregloMatriz();
        matriz.ingresa();
    }
    
}
