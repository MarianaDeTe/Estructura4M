/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arreglos;

import java.util.Scanner;

/**
 * Vazquez Garcia Mariana Karina
 */
public class BusquedaMatriz {

    Scanner leer = new Scanner(System.in);
    int[][] uno = new int[3][3];
    int num = 0;
    boolean elnum;

    /**
     * Dentro de este método se van a ingresar los valores correspondientes a
     * una matriz de 3*3, se utiliza un for en "i" para asignarle valor a las
     * filas y un for en "j" para las columnas.
     *
     * Para mostrar los resultados de la matriz se utiliza la misma secuencia,
     * con la diferencia de que no se utilizara el método de lectura "nextInt"
     */
    public void ingresa() {
        for (int i = 0; i < 3; i++) {
            System.out.println("Fila" + i);
            for (int j = 0; j < 3; j++) {
                System.out.println("ingresa número" + j);
                uno[i][j] = leer.nextInt();
            }
        }

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(uno[i][j] + "\t");
            }
            System.out.println(" ");
        }
    }

    /**
     * Con el método "LeerNumero" se hace la búsqueda dentro de la matriz, al
     * ser un arreglo bidimensional se hará uso de un for anidado, con un if que
     * se encuentra dentro.
     *
     * Dentro del if se coloca la condición de comparación.
     */
    public void LeerNumero() {
        System.out.println("Que número deseas buscar: " + "O.o??");
        num = leer.nextInt();

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (num == uno[i][j]) {
                    System.out.println("\n" + num + " se encuntra en la posicion " + i + "," + j);
                    elnum = true;
                } 
            }
        }
        if (elnum == false) {
                System.out.println("\tNo se econtro nada " + " °n°");
            }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        BusquedaMatriz bm = new BusquedaMatriz();
        bm.ingresa();
        bm.LeerNumero();
    }

}
