/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arreglos;

import java.util.Scanner;

/**
 *Vazquez Garcia Mariana Karina
 */
public class ArregloCalificaciones {

    Scanner leer = new Scanner(System.in);
    String[] nombre = new String[2];
    int[] arreglo = new int[4];
    double nota;
    double suma;

    /**
     * Dentro de este for se guardan los valores ingresados dentro de un
     * arreglo, para no tener que declarar cada variable, los valores ingresados
     * se guardaran siempre y cuando queden dentro de la declaracion(5)
     */
    public void Nombres() {
        for (int n = 0; n < nombre.length; n++) {
            System.out.println("Agrega el nombre " + n);
            nombre[n] = leer.next();

            for (int i = 0; i < arreglo.length; i++) {
                suma = 0;
                System.out.println("O.o??  " + "calificacion " + i + " de " + nombre[n]);
                arreglo[i] = leer.nextInt();
                nota = arreglo[i];
                suma += nota;
                nota = suma / arreglo.length;
            }
        }
    }

//    public void Ingresa() {
//        for (int c = 0; c < arreglo.length; c++) {
//            System.out.println("O.o??  " + "Introduce la calificacion " + c);
//
//            arreglo[c] = leer.nextInt();
//
//            suma += arreglo[c];
//            total = suma / arreglo.length;
//            arreglo[c] = 0;
////            arreglo[c]++;
//
//        }
//        System.out.println(total);
////                for (int i = 0; i < arreglo.length; i++) {
////                    suma += arreglo[i];
////                }
//
//    }
//                for (int i = 0; i < arreglo.length; i++) {
//        }
//                suma += arreglo[c];
//            }
//                System.out.println(su);
//            }
//                suma += arreglo[n];
//                
//                    System.out.println(suma);
//                    total = suma/arreglo.length;
//                    for (int j = 0; j < arreglo.length; j++) {
//                        total = suma/4;
//                    }
//                }
//            }
//                System.out.print(arreglo[n]);
//        }
    public void Muestra() {
        for (int i = 0; i < nombre.length; i++) {
//            System.out.print("\n" + nombre[i]);
            System.out.print("\nPromedio de " + nombre[i] + " " + arreglo[i]);
//            for (int j = 0; j < arreglo.length; j++) {
//                for (int k = 0; k < 10; k++) {
//                    
        }
//                
////                System.out.print(arreglo[j]);
//            }

    }
//        for (int c = 0; c < arreglo.length; c++) {
//            System.out.println(nombre[c] + " " + total);
//            System.out.println(nombre[m] + " " + arreglo[m] + " " + total);
//        }

    public static void main(String[] args) {
        ArregloCalificaciones arr = new ArregloCalificaciones();
        arr.Nombres();
        arr.Muestra();

    }

}
