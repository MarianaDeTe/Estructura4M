/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listas;

/**
 * Vazquez Garcia Mariana Karina
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

//        Lista l = new Lista();
//        l.InsertarInicio("M");
//        l.InsertarFinal("a");
//        l.InsertarFinal("r");
//        l.InsertarFinal("i");
//        l.InsertarFinal("a");
//        l.InsertarFinal("n");
//        l.InsertarFinal("a");
//        l.InsertarInicio("a");
//        l.Listar();
//        System.out.println();
//        l.EliminarInicio();
//        l.Listar();
//        System.out.println();
        
//////        ListaDoble ld = new ListaDoble();
//////        ld.InsertarInicio("r");
//////        ld.InsertarInicio("a");
//////        ld.InsertarInicio("M");
//////        ld.InsertarFinal("(°u°)");
//////        ld.InsertarFinal("(°n°)");
//////        ld.InsertarFinal("(°w°)");
//////        ld.Listar();
//////        System.out.println("Eliminando:  " + ld.ExtraerFinal());
//////        ld.Listar();
        
        ListaCircular lc = new ListaCircular();
        lc.InsertarInicio("h");
        lc.InsertarInicio("o");
        lc.InsertarInicio("l");
        lc.InsertarInicio("a");
        lc.InsertarFinal("3");
        lc.InsertarFinal("2");
        lc.ListarC();
        System.out.println();
        lc.ListarCF();
        System.out.println();
    }
}
