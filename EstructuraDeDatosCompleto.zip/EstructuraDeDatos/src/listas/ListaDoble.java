/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listas;

/**
 *
 * @author DIN
 */
public class ListaDoble {

    Nodo inicio, fin;

    public ListaDoble() {
        inicio = null;
        fin = null;
    }

    public void InsertarInicio(String info) {
        if (inicio == null) {
            inicio = new Nodo(info, null, null);
            fin = inicio;
        } else {
            Nodo nuevo = new Nodo(info, null, inicio);
            inicio.setAnt(nuevo);
            inicio = nuevo;
        }
    }

    public void InsertarFinal(String info) {
        if (inicio == null) {
            fin = new Nodo(info, fin, null);
            inicio = fin;
        } else {
            Nodo nuevo = new Nodo(info, fin, null);
            fin.setSig(nuevo);
            fin = nuevo;
        }
    }

    public void EliminarInicio() {
        inicio = inicio.sig;
    }

    public void EliminarFin() {
        fin = fin.ant;
    }

    public String ExtraerInicio() {
        String info = inicio.getInfo();
        inicio = inicio.getSig();

        if (inicio != null) {
            inicio.setAnt(null);
        }else{
            fin = null;
        }
        return info;
    }

    public String ExtraerFinal() {
        String info = fin.getInfo();
        fin = fin.getAnt();

        if (fin != null) {
            fin.setSig(null);
        } else {
            inicio = null;
        }
        return info;
    }

    public void Listar() {
        Nodo temp = inicio;
        while (temp != null) {
            System.out.println(temp.getInfo());
            temp = temp.sig;
        }
    }

    public void ListarAnte() {
        Nodo temp = fin;
        while (temp != null) {
            System.out.println(temp.getInfo());
            temp = temp.ant;
        }
    }
}
