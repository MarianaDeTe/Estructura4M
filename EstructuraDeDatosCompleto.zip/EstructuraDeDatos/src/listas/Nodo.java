/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listas;

/**
 * Vazquez Garcia Mariana Karina
 */
public class Nodo {
    private String info;
    Nodo sig;
    Nodo ant;

    /**
     * @return the info
     */
    public String getInfo() {
        return info;
    }

    /**
     * @param info the info to set
     */
    public void setInfo(String info) {
        this.info = info;
    }

    /**
     * @return the sig
     */
    public Nodo getSig() {
        return sig;
    }

    /**
     * @param sig the sig to set
     */
    public void setSig(Nodo sig) {
        this.sig = sig;
    }
    
    /**
     * @return the ant
     */
    public Nodo getAnt() {
        return ant;
    }

    /**
     * @param ant the ant to set
     */
    public void setAnt(Nodo ant) {
        this.ant = ant;
    }
    
    public Nodo(String i, Nodo s){
        info = i;
        sig = s;
    }
    
    public Nodo(String i, Nodo a, Nodo s){
        info = i;
        sig = s;
        ant = a;
    }

}
