/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listas;

/**
 *
 * @author Alumno
 */
public class ListaCircular {

    Nodo inicio, fin;

    public ListaCircular() {
        inicio = null;
        fin = null;
    }

    public void InsertarInicio(String info) {
        Nodo nuevo = new Nodo(info, inicio);
        inicio = nuevo;
        fin = inicio;
    }
//
//    public void InsertarFinal(String info) {
//        Nodo nuevo = new Nodo(info, fin);
//        if (fin == inicio) {
//            fin = nuevo;
//        } 
//        else {
//            fin.setSig(inicio);
//            fin = nuevo;
//        }
//    }

//    public void InsertarInicio(String info) {
//        if (inicio == null) {
//            inicio = new Nodo(info, null, null);
//            fin = inicio;
//        } else {
//            Nodo nuevo = new Nodo(info, null, inicio);
//            inicio.setSig(nuevo);
//            inicio = nuevo;
//        }
//    }
    /**
     * Cuando fin es igual a inicio el nodo es igual al inicio , fin apunta a
     * inicio, e inicio apunta a nuevo
     */
    public void InsertarFinal(String info) {
        if (fin == inicio) {
            if (inicio == null) {
                fin = new Nodo(info, fin, null);
                inicio = fin;
            } else {
                fin = new Nodo(info, null, inicio);
                inicio = fin;
            }
        } else {
            Nodo nuevo = new Nodo(info, fin, null);
            fin.setSig(nuevo);
            fin = nuevo;
        }
    }

//    public void InsertarFinal(String info) {
//        if (inicio == null) {
//            fin = new Nodo(info, fin, null);
//            inicio = fin;
//        } else {
//            Nodo nuevo = new Nodo(info, fin, null);
//            fin.setSig(nuevo);
//            fin = nuevo;
//        }
//    }
    public void EliminarInicio() {
        inicio = inicio.sig;
    }

    public String ExtraerInicio() {
        String info = inicio.getInfo();
        inicio = inicio.getSig();

        if (inicio == null) {
            fin = null;
        }
        return info;
    }

    public void ListarC() {
        Nodo temp = inicio;
        while (temp != null) {
            System.out.println(temp.getInfo());
            temp = temp.sig;
        }
    }

    public void ListarCF() {
        Nodo temp = fin;
        while (temp != null) {
            System.out.println(temp.getInfo());
            temp = temp.ant;
        }
    }
}
