/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linkedList;

import java.util.LinkedList;

/**
 *
 * @author DIN
 */
public class Ejemplo {
    LinkedList <String> lista = new LinkedList<String>();
    
    public void inserta(){
        lista.add("1");
        lista.addFirst("Hola");
        lista.addLast("Adios");
        lista.addLast("(°n°)/");
        
        System.out.println(lista);
    }
    
    public void busca(){
        System.out.println(lista.size());
        for (int i = 0; i < lista.size(); i++) {
            System.out.println(lista.get(i));
        }
    }
    
    public void elimina(){
        lista.pollLast();
        System.out.println(lista);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Ejemplo ej = new Ejemplo();
        ej.inserta();
        ej.busca();
        ej.elimina();
    }
    
}
