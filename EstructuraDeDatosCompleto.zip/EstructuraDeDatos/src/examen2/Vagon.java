/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examen2;

/**
 *
 * @author DIN
 */
public class Vagon {
    private String nom;
    private String matri;
    
    public Vagon(){
        this.matri = null;
    }

    /**
     * @return the nom
     */
    public String getNom() {
        return nom;
    }

    /**
     * @param nom the nom to set
     */
    public void setNom(String nom) {
        this.nom = nom;
    }

    /**
     * @return the matri
     */
    public String getMatri() {
        return matri;
    }

    /**
     * @param matri the matri to set
     */
    public void setMatri(String matri) {
//        if (matri == matri) {
//            JOptionPane.showMessageDialog(null, "Ya existe esa matricula", "Error", JOptionPane.ERROR_MESSAGE);
//        }else{
        this.matri = matri;
//        }
    }
    
}
