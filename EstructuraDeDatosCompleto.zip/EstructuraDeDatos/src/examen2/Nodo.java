/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examen2;

/**
 * Vazquez Garcia Mariana Karina
 */
public class Nodo {

    private String info;
    Nodo sig;
    Nodo ant;

    public String getInfo() {
//        return nombre + "\t" + matricula;
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public Nodo getSig() {
        return sig;
    }

    public void setSig(Nodo sig) {
        this.sig = sig;
    }

    public Nodo getAnt() {
        return ant;
    }

    public void setAnt(Nodo ant) {
        this.ant = ant;
    }

    public Nodo(String i, Nodo s) {
        info = i;
        sig = s;
    }

    public Nodo(String i, Nodo a, Nodo s) {
        info = i;
        sig = s;
        ant = a;
    }
}
