/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examen2;

import javax.swing.JOptionPane;

/**
 *
 * @author Alumno
 */
public class Propiedades {

    Nodo inicio, fin;

    public Propiedades() {
        inicio = null;
        fin = null;
    }

    public void InsertarInicio(String info) {
        if (inicio == null) {
            inicio = new Nodo(info, null, null);
            fin = inicio;
        } else {
            Nodo nuevo = new Nodo(info, null, inicio);
            inicio.setAnt(nuevo);
            inicio = nuevo;
        }
    }

    public void InsertarFinal(String info) {
        if (inicio == null) {
            fin = new Nodo(info, fin, null);
            inicio = fin;
        } else {
            Nodo nuevo = new Nodo(info, fin, null);
            fin.setSig(nuevo);
            fin = nuevo;
        }
    }

    public String Listar() {
        Nodo temp = inicio;
        String mar = null;
        while (temp != null) {
            if (mar == null) {
                mar = "";
            } else {
                mar = mar + temp.getInfo() + "\n";
                temp = temp.getSig();
            }
        }
        return mar;
    }

    public static void main(String[] args) {
        Propiedades pd = new Propiedades();
        pd.InsertarFinal("1 hgfh");
        pd.InsertarFinal("2 hgfh");
        System.out.println(pd.Listar());
    }

    public void ListarAnte() {
        Nodo temp = fin;
        while (temp != null) {
            temp.getInfo();
            temp = temp.ant;
        }
    }

    public void EliminarFin() {
        fin = fin.ant;
    }

    public String ExtraerFinal() {
        String info = fin.getInfo();
        fin = fin.getAnt();

        if (fin != null) {
            fin.setSig(null);
        } else {
            inicio = null;
        }
        return info;
    }

//    public boolean Contiene(Vagon valor) {// para declarar una variable temporal con el valor de inicio para que el valor exista en la lista
//        Nodo temp = inicio;
//        while (temp != null) {
//            if (valor.getMatri().compareTo(temp.getInfo()) == 0) {
//                return true;
//            }
//            temp = temp.getSig();
//        }
//        return false;
//    }

    public Nodo EliminarInicio() {
        Nodo temp = inicio;
        if (inicio != null) {
            inicio = inicio.getSig();
        } else {
            JOptionPane.showMessageDialog(null, "Lista Vacia", "Error (°n°)", JOptionPane.ERROR_MESSAGE);
        }
        return temp;
    }

    public String ExtraerInicio() {
        String info = inicio.getInfo();
        inicio = inicio.getSig();

        if (inicio != null) {
            inicio.setAnt(null);
        } else {
            fin = null;
        }
        return info;
    }
}
