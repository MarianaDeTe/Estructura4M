package examen2;
/* Programa que atravez de una pila que ingresan autos con datos como la matricula, nombre,  y la hora de ingreso  
 * eliminar elementos y consultar con las operaciones basicas com pop, empty, push y empty
 */

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.Stack;

public class Pila {

    Stack<Integer> numeros = new Stack<Integer>();
    Stack<String> nom = new Stack<String>();
    Stack<Date> h = new Stack<Date>();
    Scanner leer = new Scanner(System.in);
    int pla, v;
    String nombre;
    Date hora;

    /**
     * push: intorduce datos pop: elimina dato peek: muestra el ultimo dato(la
     * sima) empty: datos vacios
     */
    public void menu() {
        System.out.println("\n\n (°u°)/   Estacionamiento   (°u°)/");
        System.out.println("\n\t1)Ingresa auto");
        System.out.println("\n\t2)Consultar auto");
        System.out.println("\n\t3)Elimina auto");
        System.out.println("\n\t4)Despedida");
        System.out.println("\n\t5)Salir");
        System.out.print("\n\nElige una opción... (°o°) \n");
        int opc = leer.nextInt();
        validaOpc(opc);
    }

    private void validaOpc(int opc) {
        switch (opc) {
            case 1:
                System.out.println("Cuantos autos vas a ingresar O.o??? ");
        v = leer.nextInt();
                InsertarDato();
                menu();
                break;
            case 2:
                MostrarDato();
                menu();
                break;
            case 3:
                menu();
                break;
            case 4:
                Despedida();
                menu();
                break;
            case 5:
                System.exit(0);
                break;
            default:
                System.out.println("\n.....Opcion Invalida (°x°)......\n");
                menu();
                break;
        }
    }

    public void InsertarDato() {
        for (int i = 1; i <= v; i++) {
            System.out.println("Ingresa placas O.o??? ");
            pla = leer.nextInt();
            System.out.println("Ingresa nombre O.o??? ");
            nombre = leer.next();
            System.out.print("\t" + numeros.push(pla));
            System.out.println("\t" + nom.push(nombre));
            hora = new Date();
            System.out.println("Hora de entrada " + getHoraActual(hora));
            h.push(hora);
        }
    }

    public void MostrarDato() {
        while (!numeros.empty() || !nom.empty() || !h.empty()) {
            System.out.print("\t" + numeros.peek());
            System.out.print("\t" + nom.peek());
            System.out.println("\t" + h.peek());
            numeros.pop();
            nom.pop();
            h.pop();
        }
    }

    public void EliminarDato() {
        while (!numeros.empty() || !nom.empty() || !h.empty()) {
            System.out.print("\t" + numeros.pop());
            System.out.print("\t" + nom.pop());
            System.out.println("\t" + h.pop());
            numeros.peek();
            nom.peek();
            h.peek();
        }
    }

    private void Despedida() {
        for (int i = 0; i < 20; i++) {
            System.out.println("Adios (°n°)/");
            System.out.println("  Adios (°n°)/");
            System.out.println("    Adios (°n°)/");
            System.out.println("      Adios (°n°)/");
            System.out.println("        Adios (°n°)/");
            System.out.println("      Adios (°n°)/");
            System.out.println("    Adios (°n°)/");
            System.out.println("  Adios (°n°)/");
            System.out.println("Adios (°n°)/");
        }
    }

    public static String getHoraActual(Date hora) {
        SimpleDateFormat formateador = new SimpleDateFormat("hh:mm:ss");
        return formateador.format(hora);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Pila p = new Pila();
        p.menu();

    }
}
