package examen2;

import java.util.concurrent.TimeUnit;
import java.util.*;
import java.text.SimpleDateFormat;

public class Auto {

    private Stack<Integer> matricula = new Stack<Integer>();
    private Stack<String> mar = new Stack<String>();
    private String Nombre;
    private int v;
    private Date hora;

    Auto[] autos;
    int tope;
    final int MAX = 5;

    public Auto() {
        tope = -1;
        autos = new Auto[MAX];
    }

    public Auto(Stack<Integer> matricula, String Nombre, Date hora) {
        this.matricula = matricula;
        this.Nombre = Nombre;
        this.hora = hora;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }
    
    public Stack<Integer> getMatricula() {
        return matricula;
    }

    public void setMatricula(Stack<Integer> matricula) {
        this.matricula = matricula;
    }

    public Date gethora() {
        return hora;
    }

    public void sethora(Date hora) {
        this.hora = hora;
    }

    public void alta() {
        hora = new Date();
        System.out.println("Hora de entrada " + getHoraActual(hora));
        System.out.println("\n" + "Registro exitoso");
        
        for (int i = 1; i <= v; i++) {
            
            System.out.println(mar.push(Nombre + matricula + hora));
        }
    }

//    public String mostrarRegistro() {
//        System.out.println("Nombre : " + Nombre);
//        System.out.println("Matricula    : " + matricula);
//        System.out.println("Hora de entrada: " + getHoraActual(hora));
//        return 
//    }
    public Stack<Integer> MostrarDato() {

        while (!matricula.empty()) {
            System.out.print("\t" + matricula.peek());
            matricula.pop();
        }
        return matricula;
    }

    public void eliminar() {
        System.out.println("matricula    : " + getMatricula());
        System.out.println("Nombre : " + Nombre);
        System.out.println("Hora de entrada: " + getHoraActual(hora));

        long pago = 0;

        Date salida = new Date();
        System.out.println("Hora de salida  " + getHoraActual(salida));
        pago = getDateDiff(hora, salida, TimeUnit.MINUTES);

        System.out.println("total a pagar: " + (pago * 0.50));

        System.out.println("\n" + "El auto ha salido del sistema");

    }

    public void mostrar() {
        System.out.println("matricula    : " + getMatricula());
        System.out.println("Nombre : " + Nombre);
        System.out.println("Hora de entrada: " + getHoraActual(hora));

        String a = getMatricula() + Nombre + getHoraActual(hora);
    }

    public static long getDateDiff(Date date1, Date date2, TimeUnit timeUnit) {
        long diffInMillies = date2.getTime() - date1.getTime();
        return timeUnit.convert(diffInMillies, TimeUnit.MILLISECONDS);
    }

    public static String getHoraActual(Date hora) {
        SimpleDateFormat formateador = new SimpleDateFormat("hh:mm:ss");
        return formateador.format(hora);
    }

    
}
