/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examen1;

import java.util.Scanner;

/**
 * Vazquez Garcia Mariana Karina
 */
public class SumaRecursivaExamen {

    static int n, m;
    Scanner leer = new Scanner(System.in);

    public int Suma(int n, int m) {
        if (n == 0) {
            return 0;
        } else {
            return Suma(m,n-1) + 1;
        }
    }

    public void leerN() {
        System.out.println("\t Ingresa un numero " + "O.o??");
        n = leer.nextInt();
        System.out.println("\t Ingresa el segundo numero" + "O.o??");
        m = leer.nextInt();
        System.out.println("El número calculado es: " + Suma(n,m));
    }

    public static void main(String[] args) {
        // TODO code application logic here
        SumaRecursivaExamen sumaE = new SumaRecursivaExamen();
        sumaE.leerN();
//        sumaE.Suma(n);
    }

}
