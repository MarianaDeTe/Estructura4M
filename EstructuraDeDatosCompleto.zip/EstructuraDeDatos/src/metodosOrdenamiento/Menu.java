/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodosOrdenamiento;

import java.util.Scanner;

/**
 *
 * @author Alumno
 */
public class Menu {
    
    Scanner leer = new Scanner(System.in);
//    int[] mar = new int[7];
//    
//    public void Inicia() {
//        System.out.println("Introduce siete números para tu arreglo " + " O.o??  ");
//        for (int i = 0; i < mar.length; i++) {
//           mar[i] = leer.nextInt();
//        }
//    }

    public void Menu() {
        System.out.println("\n\n (°u°)/   MENU PRINCIPAL   (°u°)/");
        System.out.println("\n\t1)Burbuja");
        System.out.println("\n\t2)QuickSort");
        System.out.println("\n\t3)Merge");
        System.out.println("\n\t4)Salir");
        System.out.print("\n\nElige una opción... (°w°) \n");
        int opc = leer.nextInt();
        validaOpc(opc);
    }

    private void validaOpc(int opc) {
        switch (opc) {
            case 1:
                Busbuja bur = new Busbuja();
                bur.Ordena();
                bur.Muestra();
                Menu();
                break;
            case 2:
                QuickSort qs = new QuickSort();
                qs.Muestra();
                Menu();
                break;
            case 3:
                Merge mg = new Merge();
                mg.Muestra();
                Menu();
                break;
            case 4:
                System.exit(0);
                break;
            default:
                System.out.println("\n.....Opcion Invalida (°x°)......\n");
                Menu();
                break;
        }
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Menu menu = new Menu();
//        menu.Inicia();
        menu.Menu();
    }
}
