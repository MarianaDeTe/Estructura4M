/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodosOrdenamiento;

import java.util.Scanner;

/**
 * Vazquez Garcia Mariana Karina
 */
public class Busbuja extends Menu{

    Scanner busca = new Scanner(System.in);

    int[] A = {4, 3, 8, 7, 5, 9, 1};
    int aux = 0;

    /**
     * El método de burbuja es una forma de ordenamiento en la cual compara los
     * números y los encapsula, si el primer número del arreglo es mayor al
     * siguiente, lo toma al igual que el segundo, con excepción de que el
     * segundo valor lo encapsula y lo guarda en una variable para no perder el
     * valor. 
     * Se hace uso de dos "FOR", ya que el ordenamiento es parecido a
     * buscar un número dentro de una matriz por todos los recorridos que tiene
     * que dar, con la diferencia que en su búsqueda va acomodando cada valor
     * siempre y cuando sea mayor que el siguiente.      *
     */
    public void Ordena() {
        System.out.println("Tu areglo es:" + "  O.o??");
        for (int i = 0; i < A.length; i++) {
            System.out.print("\t" + A[i]);//arreglo inicial
        }

        for (int i = 0; i < A.length - 1; i++) {
            for (int j = 0; j < A.length - 1; j++) {
                if (A[j] > A[j + 1]) {
                    aux = A[j];//variable auxiliar
                    A[j] = A[j + 1];
                    A[j + 1] = aux;
                }
            }
        }
    }

    public void Muestra() {
        System.out.println("\n\n\tEl arreglo se a ordenado por método BURBUJA (°U°)");
        for (int i = 0; i < A.length; i++) {
            System.out.print(A[i] + "\t");
        }
        System.out.println("\n\n\n\t\t Adios (°U°)/");
    }

    /**
     * @param args the command line arguments
     */
//    public static void main(String[] args) {
//        // TODO code application logic here
//        Busbuja bur = new Busbuja();
//        bur.Ordena();
//        bur.Muestra();
//    }

}
