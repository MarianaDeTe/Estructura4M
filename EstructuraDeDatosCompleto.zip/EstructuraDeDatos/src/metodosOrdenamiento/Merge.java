/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodosOrdenamiento;

/**
 * Vazquez Garcia Mariana Karina.
 *
 * Es un método de ordenamiento que se basa en "divide y venceras", que tambien
 * usa la recursividad.
 */
public class Merge extends Menu{

    int m[] = {6, 7, -1, 0, 5, 2, 3, -2};

    /**
     * Lo primero que hace es tomar el arreglo y dividirlo a la mitad, despues
     * toma una mitad y la vuelve a dividir, así sucesivamente, hasta que cada
     * número a quedado solo.
     *
     * @param arreglo
     * @param init
     * @param n
     */
    public void dividirLista(int[] arreglo, int init, int n) {
        int n1;
        int n2;
        if (n > 1) {
            n1 = n / 2;//divición de lista
            n2 = n - n1;//
            dividirLista(arreglo, init, n1);
            dividirLista(arreglo, init + n1, n2);
            mezcla(arreglo, init, n1, n2);
        }
    }

    /**
     * Es en este punto donde inicia su comparación, tomando el primer valor y
     * comparandolo con el siguiente valor; Merge se basa en la condición de que
     * si la posición 1 "x" es menor al número y la posición 2 "y", tambien es
     * menor al número dos
     *
     * @param arreglo
     * @param init
     * @param n1
     * @param n2
     */
    private void mezcla(int[] arreglo, int init, int n1, int n2) {
        int[] total = new int[n1 + n2];
        int posicion = 0;
        int x = 0;//posición uno
        int y = 0;// posición dos
        int i;

        while ((x < n1) && (y < n2)) {
            if (arreglo[init + x] < arreglo[init + n1 + y]) {
                total[posicion++] = arreglo[init + (x++)];
            } else {
                total[posicion++] = arreglo[init + n1 + (y++)];
            }
        }
        while (x < n1) {
            total[posicion++] = arreglo[init + (x++)];
        }
        while (y < n2) {
            total[posicion++] = arreglo[init + n1 + (y++)];
        }
        for (i = 0; i < n1 + n2; i++) {
            arreglo[init + i] = total[i];
        }

        for (int z = 0; z < m.length; z++) {//muestra el cambio de posiciones
            System.out.print(m[z] + "\t");
        }
        System.out.println("\n");
    }

    public void Muestra() {
        System.out.println("\n\tTu arreglo es:");

        dividirLista(m, 0, 8);
        System.out.println("\n");
        System.out.println("\n\n\tEl arreglo se a ordenado por método MERGE (°U°)");
        for (int i = 0; i < m.length; i++) {
            System.out.print(m[i] + "\t");
        }
        System.out.println("\n\n\n\t\t Adios (°U°)/");
    }

    /**
     * @param args the command line arguments
     */
//    public static void main(String[] args) {
//        // TODO code application logic here
//        Merge mg = new Merge();
//        mg.Muestra();
//    }

}
