/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodosOrdenamiento;

import java.util.Scanner;

/**
 * Mariana Karina Vazquez Garcia
 *
 * Método de ordenamiento que utiliza recursividad.
 */
public class QuickSort extends Menu{

    Scanner busca = new Scanner(System.in);

    int[] a = {5, 3, 7, 6, 2, 1, 4};
    //se toma el primer elemento como pivote

    public void Resuelve(int A[], int izq, int der) {
        System.out.print("\n");
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i] + "\t");
        }

        int pivote = A[izq];
        int i = izq; // i realiza la búsqueda de izquierda a derecha
        int j = der; // j realiza la búsqueda de derecha a izquierda
        int aux;

        while (i < j) {            // mientras no se crucen las búsquedas
            while (A[i] <= pivote && i < j) {
                i++;// busca elementos MAYORES que el pivote
            }
            while (A[j] > pivote) {
                j--;// busca elemento MENORES que el pivote
            }
            if (i < j) {// si no se han cruzado                      
                aux = A[i];// los intercambia
                A[i] = A[j];
                A[j] = aux;
            }

//                    if (A[j] > A[j + 1]) {
//                    aux = A[j];//variable auxiliar
//                    A[j] = A[j + 1];
//                    A[j + 1] = aux;
//                }
        }

        A[izq] = A[j];
        /**
         * se coloca el pivote en su lugar de forma que se ordenan los menores a
         * la izquierda y los mayores a su derecha
         */
        A[j] = pivote;
        if (izq < j - 1) {
            Resuelve(A, izq, j - 1); // ordenamos subarray izquierdo
        }
        if (j + 1 < der) {
            Resuelve(A, j + 1, der); // ordenamos subarray derecho
        }
    }

    public void Muestra() {
        System.out.println("\n\tTu arreglo es:");
        Resuelve(a, 0, 6);
        System.out.println("\n\n\tEl arreglo se a ordenado por método QUICKSORT (°U°)");
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i] + "\t");
        }
        System.out.println("\n\n\n\t\t Adios (°U°)/");
    }

//    public static void main(String[] args) {
//        // TODO code application logic here
//        QuickSort qs = new QuickSort();
//        qs.Muestra();
//    }
}
