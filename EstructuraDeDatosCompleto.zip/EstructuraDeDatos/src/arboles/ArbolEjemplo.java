package arboles;

import javax.swing.JOptionPane;

/** Vazquez Garcia Mariana Karina
 *
 * Raíz: El primer nodo 
 * Padre: Que tiene más nodos 
 * Hijo: Nodo que depende de un padre 
 * Hermano: Nodos que no estan conectados pero dependen de un mismo nodo
 * Hoja: El final del árbol, no tienen más nodos 
 * Subárbol: Estructura que se encuentra dentro de otro árbol 
 * Interior: Que no son raíz ni hoja 
 * Nivel de nodo: Raíz es cero, apartir de raiz se cuenta el nodo 
 * Altura del árbol: es el maximo nivel del nodo 
 * Grado del nodo: cantidad de nodos(hijo) que tiene 
 * Grado del árbol: representa el valor mas grande de los grados de los nodos
 *
 *           (a) 
 *         /  |  \ 
 *      (b)  (c)  (d) 
 *       | \      / \ 
 *      (e) (f) (g) (h)
 *                \
 *                (i)
 *
 * Orden: 
 * Inorden: I-R-D
 * Preorden: R-I-D 
 * Posorden: I-D-R
 *
 * Árbol binario: tiene como finalidad mejorar la eficiencia de busqueda de un
 * nodo, su caracteristica principal es que todos sus hijos izquierdos son
 * menores que el, mientras que sus hijos derechos son mayores
 * 
 * Eliminar
 * 1) Cuando el nodo no tiene hijos
 * 2) Cuando el nodo solo tiene un hijo (izquierdo o derecho)
 * 3) Cuando tiene ambos hijos, se sustituye el nodo mayor del subárbol izquierdo
 * (toma el nodo que esta hubicado mas a la derecha del subárbol), o por el nodo
 * menor del subárbol derecho(toma el nodo que esta ubicado mas a la izquierda
 * del subárbol); primero elige que camino seguir, si es el derecho 
 * tomara el ultimo nodo que esta más a la izquierda, si es el camnino izquierdo
 * hara lo contrario, tomando el nodo que esta mas a la derecha, para que así se
 * siga manteniendo la condicion
 * 
 * Los recorridos visitan todos los nodos del abb (arbol binario), para mostrar
 * su contenido, hay tres formas de realizarlo
 *      a) Recorrido Preorden: Consiste en desplegar el dato del nodo actual(raíz)
 *         luego su hijo izquierdo, luego su hijo derecho R-I-D
 *      b) Recorrido Inorden: Conciste en desplegar el nodo de izquierda pasando
 *         a la raíz y terminar con el nodo que esta a la derecha
 *      c) Recorrido Posorden: Consiste en inicar el recorrido con el nodo
 *         izquierdo, siguiendo con el nodo derecho para terminar con la raíz,
 *         termina con raíz
 */

public class ArbolEjemplo {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        // TODO code application logic here
        Arbol arbol = new Arbol();
        int valor;
        String Dato;
         
        System.out.println("Los numeros ingresados son: ");
         
        Dato = JOptionPane.showInputDialog("¿De que tamaño sera el arbol?");
        int n = Integer.parseInt(Dato);
        
        for(int i = 1; i <= n; i++ )
        {
            Dato = JOptionPane.showInputDialog("El valor "
                    + i + " para el Árbol");
            valor = Integer.parseInt(Dato);
            System.out.print(valor + " ");
            arbol.insertarNodo(valor);
        }
        
        System.out.println("\n\nPreorden  (°w°)");
        arbol.recorridoPreorden();
         
        System.out.println("\n\nInorden (°w°)");
        arbol.recorridoInorden();
         
        System.out.println("\n\nPostorden (°w°)");
        arbol.recorridoPosorden();
    }
}