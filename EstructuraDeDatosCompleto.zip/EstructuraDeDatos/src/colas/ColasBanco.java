/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colas;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * Mariana Karina Vazquez Garcia
 */
public class ColasBanco {
    
    ArrayList <Object> col = new ArrayList<Object>();
    int item = 0;
    
//    Queue<Integer> cola = new LinkedList();
    String cliente, tipo;
    
    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    public void push(String p){
        col.add(p);
    }
    
    public void pop(){
        col.remove(primero());
    }
    
    public String ver(){
        String v = " ";
        for (int i = 0; i < col.size(); i++) 
//        {
            v += (i + 1) + " " + col.get(i) + "\n";
//        } "" + 
        return v;
    }
    
    public int item(){
        int q = 0;
        if (col.size() == 0) {
            q = 0;
        }else{
            q = col.size();
        }
        System.out.println(col.size());
        return q;
    }
    
    public String vacia(){
        String v = "";
        if (col.size() == 0) {
            v = "La cola esta vacia";
        }else{
            v = cliente + " Eliminado con exito";
        }
        return v;
    }
    
    public String ultimo(){
        String u = " ";
        if (col.size() == 0) {
            u = "";
        }else{
            u += col.get(col.size() - 1);
        }
        return u;
    }
    
    public String primero(){
        String p = "";
        if (col.size() == 0) {
            p = "";
        }else{
            p += col.get(0);
        }
        return p;
    }
    
    public void vaciar(){
        col.clear();
    }
    
    public String formatoFecha(){
        SimpleDateFormat formato = new SimpleDateFormat("hh:mm:ss aa");
        return formato.format(new Date());
    }
    
//    public void llenar() {
////        int[] turno = new int[5];
//        int turno = 0;
////        if (cola.isEmpty()) {
//            
//            for (int i = 1; i <= 10; i++) {
////                cola.add(tipo);
//                cola.offer(i);
//            System.out.println(cliente + i);
//            }
////        } else {
////            System.out.println("llena");
////        }
//    }
}
