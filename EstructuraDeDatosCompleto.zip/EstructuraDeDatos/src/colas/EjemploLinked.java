/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package colas;

import java.util.LinkedList;
import java.util.Queue;

/**
 * @author Alumno
 */
public class EjemploLinked {

    /**
     * @param args the command line arguments
     * 
     * poll ---cola
     * offer --cola
     * 
     * add ----linked
     * peek ---linked
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Queue<Integer> cola = new LinkedList();
        cola.offer(3);
        cola.add(14);
        cola.offer(12);
        cola.add(7);
        cola.offer(10);
        
        System.out.println("Cola llena: " + cola);
        
        while(cola.poll() != null){
            System.out.println(cola.peek());
        }
//        System.out.println(cola.peek());
    }
    
}
